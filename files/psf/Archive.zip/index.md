---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults
layout: home
author_profile: true
title: ""
permalink: /
---

<!-- FYI: enclosing text like this will make it into a comment, i.e., it won't be published -->

## About
------
<!-- If you want a picture, update the next line with the write filename (instead of img.JPG. If you don't want a picture, delete the next line.-->
<img align="left" padding-right="1em" src="img.JPG" alt="profile picture" width=200 height=200 />

Add your text here!

<!-- the next line makes sure that "News" is left aligned, i.e., not next to your picture --> 
<br clear="left"/>

## News
* add your news
* or delete! or change to something else! 

-----
<!-- Including as an example for syntax-->
## Publications
**Paper title** <br/>
Author list <br/>
*Conference/Journal name* <span style="color:red">(*This paper got an award*)</span><br/>
[<a href="#">pdf</a>] [<a href="#">video</a>]<br/>
**Another paper title** <br/>
Authors <br/>
*Conference/Journal name*<br/>
[<a href="#">pdf</a>] [<a href="#">code</a>] <br/> 


