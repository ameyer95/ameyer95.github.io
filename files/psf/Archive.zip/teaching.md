---
layout: page
title: Teaching
permalink: /teaching/
---

You can add a page listing courses you have taught, e.g.,
 
* Class A (Fall 2023)

And TA'd for
* Class 1 (TA)
* Class 2 (Head TA)

